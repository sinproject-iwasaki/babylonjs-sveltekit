const o="0.0.1";export{o as v};
